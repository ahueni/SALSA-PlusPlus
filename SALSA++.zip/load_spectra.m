function spectra=load_spectra(specchio_client, ids)

    
    spaces = specchio_client.getSpaces(ids, 1, 0, 'Acquisition Time');
    space = spaces(1);   
    space = specchio_client.loadSpace(space);
    
    
    spectra.vectors = space.getVectorsAsArray();
    spectra.wvl = space.getAverageWavelengths();
    spectra.unit = 'DN';
    spectra.instrument = space.getInstrument();
    
    spectra.ids = space.getSpectrumIds(); % get them sorted by 'Acquisition Time' (sequence as they appear in space)

    spectra.capture_times = get_acquisition_times(specchio_client, spectra.ids);


end
