%%
%   SALSA++
%
%   Interactive software for the processing of Unispec dual channel data to
%   reflectance factors. 
%   Direct connection to the SPECCHIO spectral database V3.1 or higher required.
%   Assumes that a static defintion of the SPECCHIO jar file exists in
%   classpath.txt
%
%   The browse and flag feature still requires a class implemented in the
%   old version of SPECCHIO, therefore also add the V2.2 jar file to the
%   classpath, e.g. /Users/andyhueni/Desktop/SPECCHIO_App_V2.2.0/SPECCHIO_App_V2.2.2_zeta.jar
%
%
%   For more details see also: http://www.geo.uzh.ch/en/units/rsl/news/2013/130218
%
%   (c) 2012-2014 ahueni
%
%

function SalsaPlusPlus()

    import ch.specchio.client.*;
    import ch.specchio.queries.*;
    import ch.specchio.gui.*;

    % create new window
    user_data.window_h = figure('Units', 'normalized', 'Position', [0 0 1 1], 'Name', 'SALSA++ on SPECCHIO V3', 'Color', [0.9 0.9 0.9]);

    set(user_data.window_h,'Toolbar','figure');
    
    % connect to server  
    user_data.cf = SPECCHIOClientFactory.getInstance();
    user_data.db_descriptor_list = user_data.cf.getAllServerDescriptors();    
    user_data.specchio_client = user_data.cf.createClient(user_data.db_descriptor_list.get(0)); % connect to first connection description  

    % get spectral data browser and place in window

    user_data.sdb = SpectralDataBrowser(user_data.specchio_client, true);
    user_data.sdb.build_tree();
    %user_data.qb.sdb.set_view_restriction(1); % restrict view to current user (other data cannot be processed anyway)
    
    user_data.scrollpane=jcontrol(user_data.window_h, 'javax.swing.JScrollPane', 'Position', [0 0.5 0.3 0.45]);
    user_data.scrollpane.setViewportView(user_data.sdb);
    
    set(user_data.sdb.tree, 'MouseClickedCallback', @DataBrowserAction); % there are maybe better options. Ideally, addTreeSelectionListener should be called
    set(user_data.sdb.tree, 'UserData', user_data.window_h); % ensure that we got a link from the event to the figure
    
    
%     user_data.sdb.tree.addTreeSelectionListener(user_data.qb); % this
    %raises the event in the query builder; For some reason it needs
    %redefining here (actually already set in Java ...)
    
    
    font_size = 13;
    
    
    % buttons
    gbutton=jcontrol(user_data.window_h, javax.swing.JButton('Load & Process'), 'Position', [0.57 0.96 0.1 0.03]);
    set(gbutton, 'MouseClickedCallback', @LoadRaw); 
    
    gbutton=jcontrol(user_data.window_h, javax.swing.JButton('Refine Panel Spectra'), 'Position', [0.69 0.96 0.1 0.03]);
    set(gbutton, 'MouseClickedCallback', @RefinePanelSpectra);     
    
    gbutton=jcontrol(user_data.window_h, javax.swing.JButton('Store in DB'), 'Position', [0.57 0.93 0.1 0.03]);
    set(gbutton, 'MouseClickedCallback', @StoreInDB);     
    
    
    gbutton=jcontrol(user_data.window_h, javax.swing.JButton('Browse&Flag Spectra'), 'Position', [0.69 0.93 0.1 0.03]);
    set(gbutton, 'MouseClickedCallback', @BrowseAndFlag);     
    
%     gbutton=jcontrol(user_data.window_h, javax.swing.JButton('Change DB Conn.'), 'Position', [0.82 0.93 0.1 0.03]);
%     set(gbutton, 'MouseClickedCallback', @DBConn);      


    
        
    
    % menus
    f = uimenu('Label','Housekeeping');
    uimenu(f,'Label','Instrument Definition','Callback',@InstrumentDefinition); 
    uimenu(f,'Label','Flag DC Spectra','Callback',@FlagDCSpectra);
    uimenu(f,'Label','Instrument Time Line','Callback',@InstrumentTimeLine);
    
    
    
    
    % data display axes and panels
    col1_pos = 0.35;
    col2_pos = 0.68;
    axes_width = 0.3;
    axes_height = 0.2;
    row1_pos = 0.9 - axes_height;
    row2_pos = 0.59 - axes_height;
    
    user_data.raw_A_axes = axes('Parent',user_data.window_h,'Position',[col1_pos row1_pos axes_width axes_height]);  
    user_data.raw_B_axes = axes('Parent',user_data.window_h,'Position',[col2_pos row1_pos axes_width axes_height]);  
    
    user_data.A_time_axes = axes('Parent',user_data.window_h,'Position',[col1_pos row2_pos axes_width axes_height]);  
    user_data.B_time_axes = axes('Parent',user_data.window_h,'Position',[col2_pos row2_pos axes_width axes_height]);  
    
    
    
    tgt_ref_panel = uipanel('BorderType','etchedin','Title','TGT-REF Spectra',...
		'BackgroundColor',[0.9 0.9 0.9],'Units','normalized',...
		'Position',[0 0 0.66 0.35],'Parent',user_data.window_h);
    
    
    axes_width = 0.44;
    axes_height = 0.8;  
    
    user_data.TGT_axes = axes('Parent',tgt_ref_panel,'Position',[0.05 0.95-axes_height axes_width axes_height]);  
    user_data.REF_axes = axes('Parent',tgt_ref_panel,'Position',[0.54 0.95-axes_height axes_width axes_height]);
    
    hcrf_panel = uipanel('BorderType','etchedin','Title','HCRF Spectra',...
		'BackgroundColor',[0.9 0.9 0.9],'Units','normalized',...
		'Position',[0.68 0 0.32 0.35],'Parent',user_data.window_h);
        
    axes_width = 0.9;
    user_data.wvl_int_R_axes = axes('Parent',hcrf_panel,'Position',[0.07 0.95-axes_height axes_width axes_height]);  
    
    % sliders
    user_data.spectral_pos_slider = javax.swing.JSlider(javax.swing.SwingConstants.HORIZONTAL, 1, 100, 1);
    %user_data.spectral_pos_slider.setInverted(1);
    slider = jcontrol(user_data.window_h, user_data.spectral_pos_slider, 'Position', [col1_pos row1_pos-0.05 0.3 0.02 ]);
    set(slider, 'StateChangedCallback', @PlotVersusTime);
    
    
    
    % combo boxes
    user_data.instrument_combo = uicontrol('Style', 'popup',...
           'Units', 'normalized',...
           'FontSize', font_size, ...
           'Position', [0.15 0.45 0.15 0.04]);        
       
       
    user_data.db_conn_combo = uicontrol('Style', 'popup',...
           'Units', 'normalized',...
           'FontSize', font_size, ...
           'Position', [0 0.93 0.3 0.06],  'Callback', @DBConn);        
       
       
       for i=0:user_data.db_descriptor_list.size()-1
           
           con_string{i+1} = char(user_data.db_descriptor_list.get(i).toString());
       end
       
       set(user_data.db_conn_combo,'String',con_string);
     
    
    % text boxes
    
    no_box_height = 0.02;
    no_box_x_pos = 0.51;
    no_box_y_pos_1 = 0.97;
    no_box_y_pos_2 = no_box_y_pos_1 - no_box_height*1.1;
    no_box_y_pos_3 = no_box_y_pos_2 - no_box_height*1.1;
    txt_y_offset_from_axis = 0.08;
    
    InstrumentCalFactors = uicontrol(user_data.window_h,'Style','text',...
                'String','Wavelength Cal Coeffs:',...
                'Units', 'normalized','FontSize', font_size,...
                'Position',[0 0.465 0.15 no_box_height], 'BackgroundColor', [0.9 0.9 0.9]);   
 
    InstrumentInDBText = uicontrol(user_data.window_h,'Style','text',...
                'String','SPECCHIO Instrument Name:',...
                'Units', 'normalized','FontSize', font_size,...
                'Position',[0 0.43 0.15 no_box_height], 'BackgroundColor', [0.9 0.9 0.9]);   
 
    user_data.InstrumentInDB = uicontrol(user_data.window_h,'Style','text',...
                'String','',...
                'Units', 'normalized','FontSize', font_size,...
                'Position',[0.15 0.43 0.15 no_box_height], 'BackgroundColor', [0.8 0.9 0.9]);              
            
            
    user_data.TotalSpectraText = uicontrol(user_data.window_h,'Style','text',...
                'String','Total # of selected spectra:',...
                'Units', 'normalized','FontSize', font_size,...
                'Position',[0.31 no_box_y_pos_1 0.18 no_box_height], 'BackgroundColor', [0.9 0.9 0.9]);   
    
    
    user_data.TotalSpectra = uicontrol(user_data.window_h,'Style','text',...
            'String','0',...
            'Units', 'normalized','FontSize', font_size,...
            'Position',[no_box_x_pos no_box_y_pos_1 0.05 no_box_height], 'BackgroundColor', [0.8 0.9 0.9]);   
        
        
        
    user_data.RAWSpectraText = uicontrol(user_data.window_h,'Style','text',...
                'String','# of selected RAW spectra:',...
                'Units', 'normalized','FontSize', font_size,...
                'Position',[0.31 no_box_y_pos_2 0.18 no_box_height], 'BackgroundColor', [0.9 0.9 0.9]);   
    
    
    user_data.RAWSpectra = uicontrol(user_data.window_h,'Style','text',...
            'String','0',...
            'Units', 'normalized','FontSize', font_size,...
            'Position',[no_box_x_pos no_box_y_pos_2 0.05 no_box_height], 'BackgroundColor', [0.8 0.9 0.9]);           

    
    user_data.ProcessedSpectraText = uicontrol(user_data.window_h,'Style','text',...
                'String','# of selected processed spectra:',...
                'Units', 'normalized','FontSize', font_size,...
                'Position',[0.31 no_box_y_pos_3 0.2 no_box_height], 'BackgroundColor', [0.9 0.9 0.9]);   
    
    
    user_data.ProcessedSpectra = uicontrol(user_data.window_h,'Style','text',...
            'String','0',...
            'Units', 'normalized','FontSize', font_size,...
            'Position',[no_box_x_pos no_box_y_pos_3 0.05 no_box_height], 'BackgroundColor', [0.8 0.9 0.9]);     
 
        
        
    user_data.Channel_A_content = uicontrol(user_data.window_h,'Style','text',...
            'String','',...
            'Units', 'normalized','FontSize', font_size,...
            'Position',[col1_pos row1_pos-txt_y_offset_from_axis 0.3 no_box_height], 'BackgroundColor', [0.8 0.8 0.8]);     
        
        
    user_data.Channel_B_content = uicontrol(user_data.window_h,'Style','text',...
            'String','',...
            'Units', 'normalized','FontSize', font_size,...
            'Position',[col2_pos row1_pos-txt_y_offset_from_axis 0.3 no_box_height], 'BackgroundColor', [0.8 0.8 0.8]);     
        
   
        
    user_data.current_instrument_index = 1;
    user_data=read_instrument_metadata(user_data);
        

    % store data in figure    
    set(user_data.window_h, 'UserData', user_data);   


end



function DataBrowserAction(hObject, EventData)
  
    import ch.specchio.client.*;
    import ch.specchio.queries.*;

    
    window_h = get(hObject, 'UserData');
    user_data = get(window_h, 'UserData');
        
    msgbox_h = msgbox('Selecting data from DB');
    
    % get ids of all spectra
    ids = user_data.sdb.get_selected_spectrum_ids();  
    
    
    % check if data were selected
    if(ids.size() > 0)
        
        % store info about selected hierarchy
        user_data.selected_hierarchy_id = user_data.sdb.get_selected_hierarchy_ids();
        
    
        %user_data.qb.qbb.getSelect_query()
        set(user_data.TotalSpectra, 'String', num2str(ids.size()));

        
        % Query based on pasted query from SPECCHIO Query builder:
        % >>>>>>>>>>>>>>>>>>>>>>
        query = ch.specchio.queries.Query('spectrum');
        query.setQueryType(Query.SELECT_QUERY);

        query.addColumn('spectrum_id')

        cond = ch.specchio.queries.QueryConditionObject('spectrum', 'spectrum_id');
        cond.setValue(ids);
        cond.setOperator('in');
        query.add_condition(cond);
        
        cond = EAVQueryConditionObject('eav', 'spectrum_x_eav', 'Processing Level', 'double_val');
        cond.setValue('0.0');
        cond.setOperator('=');
        query.add_condition(cond);        

        user_data.all_level0_ids = user_data.specchio_client.getSpectrumIdsMatchingQuery(query);

        %<<<<<<<<<<<<<<<<<<<<<<<<<<<
    
        % remove any garbage objects
        tmp_ids_2 = user_data.specchio_client.filterSpectrumIdsByNotHavingAttribute(user_data.all_level0_ids, 'Garbage Flag');
                
        
        % remove any DC objects
        user_data.level0_ids = user_data.specchio_client.filterSpectrumIdsByNotHavingAttribute(tmp_ids_2, 'DC Flag');
        

        set(user_data.RAWSpectra, 'String', num2str(user_data.level0_ids.size()));



        % get the Level 1.0 spectra
        % as we still got the condition object, we just replace the value       

        cond.setValue('1.0');
        level1_ids = user_data.specchio_client.getSpectrumIdsMatchingQuery(query);

        set(user_data.ProcessedSpectra, 'String', num2str(level1_ids.size()));    
        

        
        % get instrument info for all spectra
        user_data.instr_hash = get_instrument_hash(user_data);
        
        %user_data.cal_hash = get_calibration_hash(user_data)

        % set instrument name; there can be only one instance here
        if size(user_data.instr_hash , 1) == 1
        
            set(user_data.InstrumentInDB, 'String', char(user_data.instr_hash.instr.getInstrumentName()));   
            
            % check if wvls calibrations match with currently selected
            % instrument coefficients by comparing the wavelengths based on coeffs for channel A
            % with the SPECCHIO calibration
            
            bands=1:user_data.instr_hash.instr.getNoOfBands;

            % get coefficients of current instrument
            %instr_index = get(user_data.instrument_combo,'Value');

            coeffs = user_data.Instruments(user_data.current_instrument_index).coeffs_a;

            wvl  = bands.^2*coeffs(1) + bands * coeffs(2) + coeffs(3); % calculate wvl vector
            
%             diff = user_data.instr_hash.instr.getAverageWavelengths() - wvl';
%             figure
%             plot(diff)
            
            disp(['RMSE between database instrument wvls and selected wvls calibration:' num2str(rmse(user_data.instr_hash.instr.getAverageWavelengths(), wvl')) '[nm]']);
            
            
        else
            % this would result in multiple spaces anyway, i.e. this is an
            % exception that must be caught
            
            set(user_data.InstrumentInDB, 'String', 'Attention: Multiple Instruments!');
            
        end

        % store data in figure    
        set(user_data.window_h, 'UserData', user_data);   
    
    end
    
    close(msgbox_h);

end



function LoadRaw(hObject, EventData)
    import eav_db.*
    
    % get user data
    fh = ancestor(hObject.hghandle, 'figure');    
    user_data = get(fh, 'UserData');

    msgbox_h = msgbox('Loading data from DB');
    
    if isfield(user_data, 'irrad_ts')     
        user_data = rmfield(user_data, 'irrad_ts');
        user_data = rmfield(user_data, 'rad_ts');
    end
    
    
    % split data into channels A and B (here we use the sorting into lists.
    % Alternatively, we could do two queries with channels A and B
    % specified as conditions.
    
    channel_info = split_into_channels(user_data);

    
    % get information about spectral resampling from database (only channel
    % B)
%     resampling_id = Attributes.getInstance().get_attribute_id('UniSpec Spectral Resampling');
%     resampled_spectrum_ids = EAVDBServices.getInstance().filter_by_eav(raw.b.ids, resampling_id, 'string_val', 'ON');
    
    resampled_spectrum_ids = user_data.specchio_client.filterSpectrumIdsByHavingAttributeValue(channel_info.raw.b.ids, 'UniSpec Spectral Resampling', 'ON');
    
    if(resampled_spectrum_ids.size() == 0)
        user_data.unispec_spectral_resampling = 'OFF';
    else
        user_data.unispec_spectral_resampling = 'ON';
    end
    
    % load data
    user_data.raw.a = load_spectra(user_data.specchio_client, channel_info.raw.a.ids);
    user_data.raw.b = load_spectra(user_data.specchio_client, channel_info.raw.b.ids);
    
    user_data.spectrum_ids.a = channel_info.raw.a.ids;
    user_data.spectrum_ids.b = channel_info.raw.b.ids;
    
    % set the number of bands in the spectral slider
    user_data.spectral_pos_slider.setMaximum(length(user_data.raw.a.wvl));
    
    
    % assign sky or ground to channels A and B 
    user_data = assign_sky_or_gnd(user_data);
    
    % store data in figure (for below plot versus time call)   
    set(user_data.window_h, 'UserData', user_data);         
    
    
    % plot raw
    plot_2d(user_data.raw_A_axes, user_data.raw.a, 'Channel A - RAW');
    plot_2d(user_data.raw_B_axes, user_data.raw.b, 'Channel B - RAW');
    
    % plot versus time
    PlotVersusTime(hObject, 0);
    
    
    % display content information
    set(user_data.Channel_A_content, 'String', [ 'Assumed content: ' user_data.channel_a_content]);
    set(user_data.Channel_B_content, 'String', [ 'Assumed content: ' user_data.channel_b_content ' / UniSpec spec.resampl.: ' user_data.unispec_spectral_resampling]);
    
    
    % wavelength calibration: calibrates channel B if needed. Puts data
    % into next level container
    user_data = wvl_calibration(user_data);
    
    
    % wvl interpolation
    user_data = wvl_interpolation(user_data);
    
    % plot interpolated data
%     plot_2d(user_data.wvl_int_A_axes, user_data.wvl_int.sky, 'Sky - 1nm interp.');
%     plot_2d(user_data.wvl_int_B_axes, user_data.wvl_int.gnd, 'Ground - 1nm interp.');
   
    
    % split into targets and reference panel spectra
    user_data = split_gnd_spectra_into_tgt_and_ref(user_data);
    
    
    % plot targets and references
    plot_2d(user_data.TGT_axes,  user_data.wvl_int.tgt, 'Targets - 1nm interp.');
    plot_2d(user_data.REF_axes,  user_data.wvl_int.ref, 'Reference Panel - 1nm interp.');
    
    
    % calculate reflectances
    user_data = calc_reflectances(user_data);
    
    % plot reflectances
    plot_2d(user_data.wvl_int_R_axes,  user_data.wvl_int.spectra.R, 'Target Reflectances - 1nm interp.');
    %ylim(user_data.wvl_int_R_axes, [0 1]);
    
    
    % store data in figure    
    set(user_data.window_h, 'UserData', user_data);    
    
    close(msgbox_h);

end






function StoreInDB(hObject, EventData)

    import ch.specchio.types.*;
    
    % get user data
    fh = ancestor(hObject.hghandle, 'figure');    
    user_data = get(fh, 'UserData');
    
    % move up in the hierarchy to the level where the RAW resides and
    % insert new 'Processed' hierarchy

    % get directory of first spectrum
    s = user_data.specchio_client.getSpectrum(user_data.wvl_int.spectra.R.ids.get(0), false);  % load first spectrum to get the hierarchy
    current_hierarchy_id = s.getHierarchyLevelId();
        

    first_parent_id = user_data.specchio_client.getHierarchyParentId(current_hierarchy_id);  
    second_parent_id = user_data.specchio_client.getHierarchyParentId(first_parent_id);  
    
    campaign = user_data.specchio_client.getCampaign(s.getCampaignId());
    processed_hierarchy_id = user_data.specchio_client.insertHierarchy(campaign, 'Processed', second_parent_id);
    
    
    new_spectrum_ids = java.util.ArrayList();
    
     progressbar_h = progressbar( [],0,['Storing ' num2str(user_data.wvl_int.spectra.R.ids.size()) ' Reflectance Spectra']); 
    
    for i=0:user_data.wvl_int.spectra.R.ids.size()-1
    
        % copy the spectrum to new hierarchy
        new_spectrum_id = user_data.specchio_client.copySpectrum(user_data.wvl_int.spectra.R.ids.get(i), processed_hierarchy_id);

        
        % replace spectral data
        vector = user_data.wvl_int.spectra.R.vectors(i+1,:);
        user_data.specchio_client.updateSpectrumVector(new_spectrum_id, vector);
        

        new_spectrum_ids.add(java.lang.Integer(new_spectrum_id));

    
        progressbar( progressbar_h,1/user_data.wvl_int.spectra.R.ids.size() ); 
        
    end
    
    metasteps = 4;
    
    
    % change EAV entry to new Processing Level by removing old and inserting new
    progressbar( progressbar_h,metasteps, 'Updating processing level'); 
    
    attribute = user_data.specchio_client.getAttributesNameHash().get('Processing Level');
    
    user_data.specchio_client.removeEavMetadata(attribute, new_spectrum_ids);
    
    
    e = MetaParameter.newInstance(attribute);
    e.setValue(1.0);
    user_data.specchio_client.updateEavMetadata(e, new_spectrum_ids);
    
    
    % change sensor and instrument  
    progressbar( progressbar_h,metasteps/2, 'Updating sensor info');
    
    sensors = user_data.specchio_client.getSensors();
    sensor_index = 1;
    while (~strcmp(sensors(sensor_index).getName().get_value(), 'UniSpec_DC_305-1130_ip'))
        sensor_index = sensor_index + 1;
    end
    
    user_data.specchio_client.updateSpectraMetadata(new_spectrum_ids, 'sensor', sensors(sensor_index).getSensorId());
    
    user_data.specchio_client.updateSpectraMetadata(new_spectrum_ids, 'instrument', 0);
    
    
    % set unit to reflectance
    progressbar( progressbar_h,metasteps/3, 'Updating units');
    
    category_values = user_data.specchio_client.getMetadataCategoriesForNameAccess(Spectrum.MEASUREMENT_UNIT);
    reflectance_id = category_values.get('Reflectance');
    user_data.specchio_client.updateSpectraMetadata(new_spectrum_ids, 'measurement_unit', reflectance_id);
    
    
    % set beam geometry to hemispherical-conical
    progressbar( progressbar_h,metasteps/4, 'Setting beam geometry');
    
    beam_geometry_attribute = user_data.specchio_client.getAttributesNameHash().get('Beam Geometry');
    beam_id = user_data.specchio_client.getTaxonomyId(beam_geometry_attribute.getId(), 'Hemispherical-conical (CASE 8)');
    
    e = MetaParameter.newInstance(beam_geometry_attribute);
    e.setValue(beam_id);
    user_data.specchio_client.updateEavMetadata(e, new_spectrum_ids);
    
    progressbar( progressbar_h,-1 );
    
    
    msgbox(['Reflectances are stored in DB (' num2str(new_spectrum_ids.size()) ' spectra were inserted)'],'SALSA++');

end


function DBConn(hObject, EventData)

    import ch.specchio.gui.*;

    
    % get user data
    fh = ancestor(hObject, 'figure');    
    user_data = get(fh, 'UserData');
    
    index = get(hObject,'Value');
    
    user_data.specchio_client = user_data.cf.createClient(user_data.db_descriptor_list.get(index-1));   
    
    %user_data.scrollpane.removeAll();
    
    user_data.sdb = SpectralDataBrowser(user_data.specchio_client, true);
    user_data.sdb.build_tree();
    %user_data.qb.sdb.set_view_restriction(1); % restrict view to current user (other data cannot be processed anyway)
    
    user_data.scrollpane.setViewportView(user_data.sdb);
    
    set(user_data.sdb.tree, 'MouseClickedCallback', @DataBrowserAction); % there are maybe better options. Ideally, addTreeSelectionListener should be called
    set(user_data.sdb.tree, 'UserData', user_data.window_h); % ensure that we got a link from the event to the figure
    
    
    % show connection panel
%     d = ch.specchio.gui.DatabaseConnectionDialog();
%     d.setVisible(true);
%     
%     
%     specchio = ch.specchio.gui.SPECCHIOApplication.getInstance();
%     
%     client=specchio.getClient()
%     
%     client.getServerDescriptor()
%     
%     user_data.specchio_client.getServerDescriptor()

    % store data in figure
    set(user_data.window_h, 'UserData', user_data);

    
end







function FlagDCSpectra(hObject, EventData)
    
    % get user data
    fh = ancestor(hObject, 'figure');   
    user_data = get(fh, 'UserData');
    
    
    % create new window
    window_h = figure('Units', 'normalized', 'Position', [0 0 0.5 0.5], 'Name', 'SALSA++ DC Spectra Flagging', 'Color', [0.9 0.9 0.9]);

    set(window_h,'Toolbar','figure');
    
    
    col1_pos = 0.05;
    col2_pos = 0.55;
    axes_width = 0.4;
    axes_height = 0.4;
    row1_pos = 0.9 - axes_height;
    row2_pos = 0.6 - axes_height;
    
    A_DC_axes = axes('Parent',window_h,'Position',[col1_pos row1_pos axes_width axes_height]);  
    B_DC_axes = axes('Parent',window_h,'Position',[col2_pos row1_pos axes_width axes_height]);   
    
    gbutton=jcontrol(window_h, javax.swing.JButton('Flag the identified spectra'), 'Position', [0.57 0.1 0.2 0.03]);
    set(gbutton, 'MouseClickedCallback', @FlagIdentifiedDCSpectra);     
    
    
    % Identify the DC spectra
    DC_stdev_threshold = 100;
    
    Sky_DC_spectra_index = get_dc_index(user_data.wvl_cal.sky.vectors, DC_stdev_threshold);
    GND_DC_spectra_index = get_dc_index(user_data.wvl_cal.gnd.vectors, DC_stdev_threshold);    
    
    
    user_data.DC_data.sky = get_subset_data_structure(user_data.wvl_cal.sky, Sky_DC_spectra_index);
    user_data.DC_data.gnd = get_subset_data_structure(user_data.wvl_cal.gnd, GND_DC_spectra_index);
    
    
    % plot
    plot_2d(A_DC_axes,  user_data.DC_data.sky, ['Channel A - DC    N = ' num2str(user_data.DC_data.sky.ids.size())]);
    plot_2d(B_DC_axes,  user_data.DC_data.gnd, ['Channel B - DC    N = ' num2str(user_data.DC_data.gnd.ids.size())]);
    
    
    
    % store data in figure    
    set(window_h, 'UserData', user_data);     
    


end


function FlagIdentifiedDCSpectra(hObject, EventData)
    
    % get user data
    fh = ancestor(hObject.hghandle, 'figure');    
    user_data = get(fh, 'UserData');

    
    % insert DC flag for all identified DC spectra
    insert_flag(user_data.DC_data.sky.ids, 'DC Flag');
    insert_flag(user_data.DC_data.gnd.ids, 'DC Flag');

end








function subset = get_subset_data_structure(data, index)

    % compile new spectrum id lists based on the clustering result
    class_1_list = java.util.ArrayList();
    
    for i=1:length(index)
        
        if index(i) == 1
            class_1_list.add(java.lang.Integer(data.ids.get(i-1)));                       
        end
                
    end
    
    
    subset.vectors = (data.vectors(index == 1, :));
    
    subset.ids = class_1_list;
    
    subset.wvl = data.wvl;
    
    subset.unit = data.unit;
    



end


function DC_spectra_index = get_dc_index(spectra, threshold)

    % standard deviations per spectrum
    stdevs = zeros(size(spectra,1),1);
    for i=1:size(spectra,1)
        
        stdevs(i) = std(spectra(i,:));
        
    end
    
    DC_spectra_index = stdevs < 100;

end


% adapted from SALSA V3
% channel A contains sky if values are on average greater than channel B
function user_data=assign_sky_or_gnd(user_data)

    decisionIndexRange = 25:200;

    decision_matrix = user_data.raw.a.vectors(:, decisionIndexRange) > user_data.raw.b.vectors(:, decisionIndexRange);
    mean_decision = mean(mean(decision_matrix));

    if(mean_decision > 0.5)       
        user_data.channel_a_content = 'Sky';
        user_data.channel_b_content = 'Ground';
    else
        user_data.channel_b_content = 'Sky';
        user_data.channel_a_content = 'Ground'; 
    end


end



function user_data = wvl_calibration(user_data)

    if (strcmp(user_data.unispec_spectral_resampling, 'OFF'))
        % need to calibrate the wvl of channel B
        
        bands=1:length(user_data.raw.b.wvl);
        
        % get coefficients of current instrument
        %instr_index = get(user_data.instrument_combo,'Value');
        
        coeffs = user_data.Instruments(user_data.current_instrument_index).coeffs_b;
        
        b =  user_data.raw.b; % inital copy
        b.wvl  = bands.^2*coeffs(1) + bands * coeffs(2) + coeffs(3); % replace wvl vector

    else
        % already calibrated by UniSpec
        b =  user_data.raw.b; % just a copy for channel B        
    end

    
    % put into correct container (sky or ground)
    if (strcmp(user_data.channel_a_content, 'Sky'))        
        user_data.wvl_cal.sky = user_data.raw.a; % just a copy for channel A
        user_data.wvl_cal.gnd = b;         
    else        
        user_data.wvl_cal.sky = b; 
        user_data.wvl_cal.gnd = user_data.raw.a; % just a copy for channel A                
    end
    
    

end




function user_data = wvl_interpolation(user_data)


    start_wvl = 305;
    end_wvl = 1130;

    new_wvl =(start_wvl:end_wvl);
    
    % create empty matrices
    user_data.wvl_int.sky.vectors = zeros(size(user_data.wvl_cal.sky.vectors,1), length(new_wvl));
    user_data.wvl_int.gnd.vectors = zeros(size(user_data.wvl_cal.gnd.vectors,1), length(new_wvl));
    
    % interpolate
    for i=1:size(user_data.wvl_cal.sky.vectors,1)      

        user_data.wvl_int.sky.vectors(i,:) = interp1(user_data.wvl_cal.sky.wvl, user_data.wvl_cal.sky.vectors(i,:), new_wvl, 'linear','extrap');
        user_data.wvl_int.gnd.vectors(i,:) = interp1(user_data.wvl_cal.gnd.wvl, user_data.wvl_cal.gnd.vectors(i,:), new_wvl, 'linear','extrap');

    end

    user_data.wvl_int.sky.wvl = new_wvl;
    user_data.wvl_int.gnd.wvl = new_wvl;
    
    user_data.wvl_int.sky.unit = user_data.wvl_cal.sky.unit;
    user_data.wvl_int.gnd.unit = user_data.wvl_cal.gnd.unit;
    
    user_data.wvl_int.sky.ids = user_data.wvl_cal.sky.ids;
    user_data.wvl_int.gnd.ids = user_data.wvl_cal.gnd.ids;    
    
end



function user_data = split_gnd_spectra_into_tgt_and_ref(user_data)

% PCA approach
%     X_t=user_data.wvl_int.spectra.gnd.vectors';
% 
%     eigv=pcafunc(user_data.wvl_int.spectra.gnd.vectors, 2);
% 
%     for i=1:size(user_data.wvl_int.spectra.gnd.vectors, 1)
% 
%        X_red(i,:) =  eigv' * X_t(:,i);
%         
%     end
%     plot(X_red(:,1), X_red(:,2), 'o'); % plots the clusters

    X_t = user_data.wvl_int.gnd.vectors';
    
    % kmeans classification with 2 clusters
    [L,C] = kmeans(X_t,2);
    
    
    
    % compile new spectrum id lists based on the clustering result
    class_1_list = java.util.ArrayList();
    class_2_list = java.util.ArrayList();
    
    for i=1:length(L)
        
        if L(i) == 1
            class_1_list.add(java.lang.Integer(user_data.wvl_int.gnd.ids.get(i-1)));           
        else
            class_2_list.add(java.lang.Integer(user_data.wvl_int.gnd.ids.get(i-1)));             
        end
                
    end
    
    
    % check what are the references and what the targets, depending on the
    % count per class
    class_1_cnt = sum(L == 1);   
    class_2_cnt = sum(L == 2);    

    
    if class_1_cnt > class_2_cnt
        % class 1 are the targets
        user_data.wvl_int.tgt.vectors = (X_t(:,L == 1))';
        user_data.wvl_int.ref.vectors = (X_t(:,L == 2))';
        user_data.tgt_index = L == 1;
        user_data.ref_index = L == 2; 
        user_data.wvl_int.tgt.ids = class_1_list;
        user_data.wvl_int.ref.ids = class_2_list;                
    else
        % class 2 are the targets
        user_data.wvl_int.tgt.vectors = (X_t(:,L == 2))';
        user_data.wvl_int.ref.vectors = (X_t(:,L == 1))'; 
        user_data.tgt_index = L == 2;
        user_data.ref_index = L == 1; 
        user_data.wvl_int.tgt.ids = class_2_list;
        user_data.wvl_int.ref.ids = class_1_list;                        
    end
    
    user_data.wvl_int.tgt.wvl = user_data.wvl_int.gnd.wvl;
    user_data.wvl_int.ref.wvl = user_data.wvl_int.gnd.wvl;
    
    user_data.wvl_int.tgt.unit = user_data.wvl_int.gnd.unit;
    user_data.wvl_int.ref.unit = user_data.wvl_int.gnd.unit;  
    
    
    % create inital indices for the selected and disabled panel spectra
    tmp = zeros(user_data.wvl_int.ref.ids.size(), 1);
    user_data.wvl_int.ref.selected_index = tmp == 0;
    user_data.wvl_int.ref.disabled_index = ~user_data.wvl_int.ref.selected_index;
    
    % create index for all panel spectra to speed up plotting during panel
    % refinement
    user_data.wvl_int.ref.all_index = user_data.wvl_int.ref.selected_index;       
    
end







function user_data=read_instrument_metadata(user_data)

    tmp = load('SalsaInstrumentCoefficients.mat');
    user_data.Instruments = tmp.Instruments;
    
    
    user_data=build_instr_combo_content(user_data);

end




function InstrumentDefinition(hObject, EventData)

    h = defineInstrumentCoefficients();
    
    uiwait(h);
    
    % update the drop down instrument combo with new instrument settings
    fh = ancestor(hObject, 'figure');   
    user_data = get(fh, 'UserData');
    
    user_data=read_instrument_metadata(user_data);
    
    % store data in figure    
    set(user_data.window_h, 'UserData', user_data);    
       
end



function PlotVersusTime(hObject, EventData)


    fh = ancestor(hObject.hghandle,'figure');% gets the parent figure handle
    
    % get user data
    user_data = get(fh, 'UserData');
    
    if (~user_data.spectral_pos_slider.getValueIsAdjusting())        
    
        band = user_data.spectral_pos_slider.getValue();
        
        % check if timeseries already exists: this is for the speed up of
        % the interface ...
        if ~isfield(user_data, 'irrad_ts') 
            % create time series
            user_data.irrad_ts = timeseries(user_data.raw.a.vectors(:, band), user_data.raw.a.capture_times);
            user_data.rad_ts = timeseries(user_data.raw.b.vectors(:, band), user_data.raw.b.capture_times);
            
            % store data in figure    
            set(user_data.window_h, 'UserData', user_data);   
            
        else
            
            user_data.irrad_ts.Data = user_data.raw.a.vectors(:, band);
            user_data.rad_ts.Data = user_data.raw.b.vectors(:, band);            
        end


        set(user_data.window_h,'CurrentAxes',user_data.A_time_axes);
        plot(user_data.irrad_ts);
        hold(user_data.A_time_axes)    
        plot(user_data.irrad_ts, 'og', 'MarkerFaceColor', 'g');
        hold(user_data.A_time_axes)
        title(user_data.A_time_axes, ['Sky Irradiance over time @ ' num2str(user_data.raw.a.wvl(band)) 'nm']);

        set(user_data.window_h,'CurrentAxes',user_data.B_time_axes);

        plot(user_data.rad_ts);
        hold(user_data.B_time_axes);
        plot(user_data.rad_ts, 'og', 'MarkerFaceColor', 'g');
        hold(user_data.B_time_axes);
        title(user_data.B_time_axes, ['Ground Radiance over time @ ' num2str(user_data.raw.b.wvl(band)) 'nm']);



    %     plot(user_data.A_time_axes, user_data.raw.a.capture_times, user_data.raw.a.vectors(:, band), 'og');
    %     hold(user_data.A_time_axes)
    %     plot(user_data.A_time_axes, user_data.raw.a.capture_times, user_data.raw.a.vectors(:, band));
    %     hold(user_data.A_time_axes)
    %     
    %     
    %     plot(user_data.B_time_axes, user_data.raw.b.capture_times, user_data.raw.b.vectors(:, band));  
    %     
    %     title(user_data.A_time_axes, ['Sky Irradiance over time @ ' num2str(user_data.raw.a.wvl(band)) 'nm']);
    %     title(user_data.B_time_axes, ['Ground Radiance over time @ ' num2str(user_data.raw.b.wvl(band)) 'nm']);
    
    end

end

