function string=escape_(string)


    string = regexprep(string, '_', '\\_');


end