function insert_flag(ids, flag)

%     import specchio.*
%     import eav_db.*
    
            
    e = MetaParameter('system', 'specchio');    
    e.setAttribute_name(flag);
    e.setValue(1, 'Raw');
    
    
    
    
%     eav_id = e.insert_into_db();
% 
%     for i=0:ids.size()-1
%         
%         % add EAV entry link
%         EAVDBServices.getInstance().insert_primary_x_eav(ids.get(i), eav_id);
% 
%     end

end
