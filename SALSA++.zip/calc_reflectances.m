function user_data = calc_reflectances(user_data)


    % get sky spectra based on the target index / ref index (equivalent to the sky
    % spectrum matching the target or reference respectively)
    sky_tgt = user_data.wvl_int.sky.vectors(user_data.tgt_index, :);
    sky_ref = user_data.wvl_int.sky.vectors(user_data.ref_index, :);
    
    % calculate the average of the panel spectra, the used entries depend
    % on the selected reference panel settings
    panel_factors = user_data.wvl_int.ref.vectors(user_data.wvl_int.ref.selected_index,:) ./ sky_ref(user_data.wvl_int.ref.selected_index,:);
    
    panel_avg = mean(panel_factors);
    
    % replicate average to allow matrix operations
    panel_avg_matrix = repmat(panel_avg, size(user_data.wvl_int.tgt.vectors, 1), 1);    

    user_data.wvl_int.spectra.R.vectors = user_data.wvl_int.tgt.vectors ./ (sky_tgt .* panel_avg_matrix);
    user_data.wvl_int.spectra.R.wvl = user_data.wvl_int.tgt.wvl;
    user_data.wvl_int.spectra.R.unit = 'HCRF';
    user_data.wvl_int.spectra.R.ids = user_data.wvl_int.tgt.ids;
    

end
