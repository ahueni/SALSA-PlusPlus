function BrowseAndFlag(hObject, EventData)

    import javax.swing.JTable;
    import javax.swing.table.DefaultTableModel;
    import java.awt.Dimension;
    import javax.swing.JScrollPane;

    
    % get user data
    fh = ancestor(hObject.hghandle, 'figure');    
    user_data = get(fh, 'UserData');


    % create new window
    window_h = figure('Units', 'normalized', 'Position', [0 0 0.7 0.5], 'Name', 'SALSA++ Browse & Flag', 'Color', [0.9 0.9 0.9]);
    user_data.browse_and_flag.window_h = window_h;
    
    set(window_h,'Toolbar','figure');
    
    
    col1_pos = 0.3;
    col2_pos = 0.65;
    axes_width = 0.3;
    axes_height = 0.4;
    row1_pos = 0.9 - axes_height;
    row2_pos = 0.45 - axes_height;
    
    user_data.browse_and_flag.A_axes = axes('Parent',window_h,'Position',[col1_pos row1_pos axes_width axes_height]);  
    user_data.browse_and_flag.B_axes = axes('Parent',window_h,'Position',[col2_pos row1_pos axes_width axes_height]);       

    user_data.browse_and_flag.A_time_axes = axes('Parent',window_h,'Position',[col1_pos row2_pos axes_width axes_height]);  
    user_data.browse_and_flag.B_time_axes = axes('Parent',window_h,'Position',[col2_pos row2_pos axes_width axes_height]);  
    
    
    % load level0 data
    
    
    
    % split data into channels A and B (here we use the sorting into lists.
    % Alternatively, we could do two queries with channels A and B
    % specified as conditions.
    
    groups = user_data.specchio_client.sortByAttributes(user_data.level0_ids, 'Instrument Channel');
    channel_lists = groups.getSpectrum_id_lists();
    
%     
%     channel_attr_id = Attributes.getInstance().get_attribute_id('Instrument Channel');
%     
%     
%     groups = AV_MatchingListCollection();
%     groups.insert_into_lists(user_data.all_level0_ids, channel_attr_id);
%     channel_lists = groups.get_lists();
    
    if(channel_lists.get(0).get_properties_summary().equals('Instrument Channel:A'))
        
        raw.a.ids = channel_lists.get(0).getSpectrumIds();
        raw.b.ids = channel_lists.get(1).getSpectrumIds();
        
    else
        
        raw.b.ids = channel_lists.get(0).getSpectrumIds();
        raw.a.ids = channel_lists.get(1).getSpectrumIds();        
        
    end    
    
    % load data
    user_data.all_level0.a = load_spectra(user_data.specchio_client, raw.a.ids);
    user_data.all_level0.b = load_spectra(user_data.specchio_client, raw.b.ids);    
    
    
    
    
    % build table
    
%     javaaddpath ({'/Users/andyhueni/Data/JavaProjects/eclipse workspaces/Specchio/matlab_integration/SpectraNamesAndFlagsTableModel.class'});
%     javaaddpath ({'./SpectraNamesAndFlagsTableModel.class'});
%     import matlab_integration.*
    
    model = matlab_integration.SpectraNamesAndFlagsTableModel();
		

    model.addColumn('Filename');
    model.addColumn('DC Flag');
    model.addColumn('Garbage Flag');
    model.setRowCount(raw.a.ids.size());

    user_data.SpectraNamesAndFlagsTableModel = model;

    table = JTable(model);
    d =  Dimension(350,150);
    table.setPreferredScrollableViewportSize(d);   
    
    
%     sms = SpecchioMetadataServices();
%     filenames = sms.get_spectrum_table_field(user_data.all_level0.a.ids, 'file_name');
    
    filenames = user_data.specchio_client.getMetaparameterValues(user_data.all_level0.a.ids, 'File Name');    
    
    
%     dc_spectra_ids = EAVDBServices.getInstance().filter_by_eav(user_data.all_level0.a.ids, Attributes.getInstance().get_attribute_id('DC Flag'));
%     garbage_spectra_ids = EAVDBServices.getInstance().filter_by_eav(user_data.all_level0.a.ids, Attributes.getInstance().get_attribute_id('Garbage Flag'));

    dc_spectra_ids = user_data.specchio_client.filterSpectrumIdsByHavingAttribute(user_data.all_level0.a.ids, 'DC Flag');
    garbage_spectra_ids = user_data.specchio_client.filterSpectrumIdsByHavingAttribute(user_data.all_level0.a.ids, 'Garbage Flag');
    
    for i=0:filenames.size() - 1
        
        cur_id = user_data.all_level0.a.ids.get(i);
        
        table.setValueAt(filenames.get(i), i, 0);
        
        if dc_spectra_ids.contains(java.lang.Integer(cur_id)) % integer conversion needed, otherwise it is Double!
            table.setValueAt(java.lang.Boolean(true), i, 1);
        else       
            table.setValueAt(java.lang.Boolean(false), i, 1);
        end
        
         if garbage_spectra_ids.contains(java.lang.Integer(cur_id)) % integer conversion needed, otherwise it is Double!
            table.setValueAt(java.lang.Boolean(true), i, 2);
        else       
            table.setValueAt(java.lang.Boolean(false), i, 2);
        end       
        
    end
    
    scroll_pane =  JScrollPane();
    
    scroll_pane.getViewport().add(table);
    
    
    table_h=jcontrol(window_h, scroll_pane, 'Position', [0 0.0 0.28 1]);
    
    % add listener to table
    set(table, 'MouseClickedCallback', {@DisplaySelectedSpectra,user_data.window_h});     
    set(table, 'KeyPressedCallback', {@DisplaySelectedSpectra,user_data.window_h});
    set(model, 'TableChangedCallback', {@FlagEdit,user_data.window_h});
    

    user_data.browse_and_flag.jtable = table;
    
    % store data in figure    
    set(user_data.window_h, 'UserData', user_data);          
    
    % display first row
    table.changeSelection(0,0, 1, 0);
    DisplaySelectedSpectra(0, 0, user_data.window_h);
    

    
end




function DisplaySelectedSpectra(hObject, EventData, window_h)


    user_data = get(window_h, 'UserData');

    % get the selected row
    row_index = user_data.browse_and_flag.jtable.getSelectedRows() + 1;


    plot_2d(user_data.browse_and_flag.A_axes, user_data.all_level0.a, 'Channel A - RAW', row_index);
    plot_2d(user_data.browse_and_flag.B_axes, user_data.all_level0.b, 'Channel B - RAW', row_index);

     
    %band = user_data.spectral_pos_slider.getValue();
    band = 50;
    
    % create time series
    irrad_ts = timeseries(user_data.all_level0.a.vectors(:, band), user_data.all_level0.a.capture_times);
    rad_ts = timeseries(user_data.all_level0.b.vectors(:, band), user_data.all_level0.b.capture_times);
    
    selected_point_irrad_ts = timeseries(user_data.all_level0.a.vectors(row_index, band), {user_data.all_level0.a.capture_times{row_index}});
    selected_point_rad_ts = timeseries(user_data.all_level0.b.vectors(row_index, band), {user_data.all_level0.b.capture_times{row_index}});
    
    
    set(user_data.browse_and_flag.window_h,'CurrentAxes',user_data.browse_and_flag.A_time_axes);
    plot(irrad_ts);
    hold(user_data.browse_and_flag.A_time_axes)    
    plot(irrad_ts, 'og', 'MarkerFaceColor', 'g');
    plot(selected_point_irrad_ts, '*r', 'MarkerFaceColor', 'r', 'MarkerSize', 15);
    hold(user_data.browse_and_flag.A_time_axes)
    title(user_data.browse_and_flag.A_time_axes, ['Sky Irradiance over time @ ' num2str(user_data.all_level0.a.wvl(band)) 'nm']);
    
    set(user_data.browse_and_flag.window_h,'CurrentAxes',user_data.browse_and_flag.B_time_axes);
    
    plot(rad_ts);
    hold(user_data.browse_and_flag.B_time_axes);
    plot(rad_ts, 'og', 'MarkerFaceColor', 'g');
    plot(selected_point_rad_ts, '*r', 'MarkerFaceColor', 'r', 'MarkerSize', 15);
    hold(user_data.browse_and_flag.B_time_axes);
    title(user_data.browse_and_flag.B_time_axes, ['Ground Radiance over time @ ' num2str(user_data.all_level0.b.wvl(band)) 'nm']);
        
    

end



function FlagEdit(hObject, EventData, window_h)

    import ch.specchio.types.MetaParameter;

    user_data = get(window_h, 'UserData');
    
    row = EventData.getFirstRow();    
    col = EventData.getColumn();
    
    if col == 1 || col == 2
    
        % get the actual value
        flag = user_data.SpectraNamesAndFlagsTableModel.getValueAt(row, col);

        ids = java.util.ArrayList();

        % add A and B spectra ids
        ids.add(java.lang.Integer(user_data.all_level0.a.ids.get(row)));
        ids.add(java.lang.Integer(user_data.all_level0.b.ids.get(row)));    

        if col == 1 % DC flag
            flag_name = 'DC Flag';
        end

        if col == 2 % Garbage flag
            flag_name = 'Garbage Flag';
        end  

        flag_attribute = user_data.specchio_client.getAttributesNameHash().get(flag_name);

        if flag == 1
            % insert flag            
            e = MetaParameter.newInstance(flag_attribute);
            e.setValue(1);
            
            user_data.specchio_client.updateEavMetadata(e, ids);

        else

            % remove flag            
            user_data.specchio_client.removeEavMetadata(flag_attribute, ids);

        end

    
    end

end





