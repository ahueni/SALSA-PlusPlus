function times = get_acquisition_times(specchio_client, spectrum_ids)

    acq_times = specchio_client.getMetaparameterValues(spectrum_ids, 'Acquisition Time');    


    % compile SPECCHIO capture times into a format expected by Matlab
    times = cell(spectrum_ids.size(),1);

    formatter = java.text.SimpleDateFormat('MMM.dd,yyyy hh:mm:ss');

    for i=1:spectrum_ids.size()
        times{i} = char(formatter.format(acq_times.get(i-1)));
    end

    
end