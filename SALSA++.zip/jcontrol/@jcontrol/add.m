function add(obj)

if isfloat(obj)
end

return
end
